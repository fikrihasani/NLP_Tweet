# NLP_Tweet
NLP text categorization experiment for data tweet of bandung citizen. 
Class project but can be used for further experiment
